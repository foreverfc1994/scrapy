from scrapy import cmdline
cmdline.execute("scrapy crawl mop".split())
