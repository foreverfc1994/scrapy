from scrapy import cmdline
cmdline.execute("scrapy crawl tianya_bbs".split())
